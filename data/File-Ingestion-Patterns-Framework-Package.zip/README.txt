FILE INGESTION PATTERNS — PATTERN FRAMEWORK DEMONSTRATION PACKAGE (LINEAGE 3)
Canada Life Pattern Framework v1.4 · Anchored on existing catalog EDP-5 and
EDP-4, grounded in their actual pattern pages

CONTENTS (read 00-Package-Overview.docx first)
  00  Package Overview (start here — links to everything)
  01  L1 Architecture Style — File-Based Integration (NEW style proposal —
      framework extensibility demonstrated)
  02  L2 Architecture Pattern — Valet Key
  03  L2 Architecture Pattern — Gatekeeper
  04  L3 Solution Pattern — Secure Client File Ingestion (new — bridges the
      lineage gap above EDP-5/EDP-4)
  05  L4 EDP-5 — Client File Upload (EXISTING catalog EDP, identity and
      approvals preserved, re-expressed; GCP tag flagged for containment)
  06  L4 EDP-4 — AV Scanning (EXISTING catalog EDP, re-expressed; Under
      Review recommended per v1.4 triggers — tactical engine decision
      pending AV standardization, approver deactivated)

Companion to the Web Application Patterns package (Lineage 1) and the
Event-Driven Patterns package (Lineage 2).

IMPORTANT — CROSS-DOCUMENT LINKS
Extract ALL files into ONE folder and keep them together. Hyperlinks
between documents are relative and resolve only when the files sit side
by side. Do not rename the files. Word may show a security prompt on
first click of a cross-document link; choose Yes/Allow.
