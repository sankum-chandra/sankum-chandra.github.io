# EDP — Single Page Web App Hosting on AWS

*Authored in the EXISTING engineering EDP format (per the current Confluence template, as used by EDP-16), demonstrating that framework alignment requires no format change — only pattern substance and lineage. Additions relative to current practice are marked ⭑.*

## Table Of Contents
Pattern Summary · Description · How it works · Diagram · Use Cases · Goals & Benefits · Limitations · Components/Services · When To Use · Related Patterns ⭑ · Security · Cost Model · Deployment Strategy · Review History · Appendix

## Pattern Summary

| Column Name | Column Value |
|---|---|
| Pattern ID | EDP-27 *(placeholder — assign next sequential number in the Confluence design pattern catalog)* |
| Pattern Name | Single Page Web App Hosting on AWS |
| Type | Delivery *(suggested — confirm against TBM Taxonomy value list)* |
| Category | Development *(suggested — confirm)* |
| Name | Application Hosting *(suggested — confirm)* |
| Cloud Specific | Yes |
| Cloud Service Provider(s) | AWS |
| Service Offering(s) | AWS Amplify Hosting *(offering page TBD)*, Amazon CloudFront *(TBD)*, AWS WAF *(TBD)*, Amazon API Gateway *(TBD)*, Amazon Cognito *(TBD)*, Amazon Route 53 *(TBD)*, Amazon CloudWatch *(TBD)* |
| Status | DRAFT |
| ⭑ Pattern Lineage | Solution Pattern: **Single Page Web App** → Architecture Patterns: **Static Content Hosting**, **Gateway**, **Federated Identity** → Architecture Style: **N-Tier (Web-Based)** |
| ⭑ Sibling EDP(s) | Single Page Web App Hosting on Azure *(planned — same parent Solution Pattern)* |
| Solution Architect | @*(to assign — I&O Solution Architecture)* |
| Reviewer(s) | @*(I&O Engineering)*, @*(BISO — security implications present)* ⭑ |
| Approver(s) | @*(Design Authority per Framework v1.4 RACI)* |
| Approved Date | — |

## Description

This pattern defines the approved way to host a **Single Page Web Application** on AWS: a browser-executed application shell delivered through edge-secured static hosting, with all dynamic interaction flowing as authenticated API calls through a governed gateway, and user authentication federated to the enterprise identity provider.

It realizes the **Single Page Web App Solution Pattern** on AWS. The engineering decisions below are the AWS-concrete form of that pattern's composition; the architectural intent (trust boundaries, single API entry, federated identity, edge-secured shell delivery) is inherited from the lineage and is not renegotiable at this level — deviations require a governed exception via the Design Authority.

## How it works

1. **Shell delivery.** The application shell (HTML/JS/CSS produced by the team's build) is hosted on **AWS Amplify Hosting**, fronted by **Amazon CloudFront** with an **AWS WAF** web ACL (AWS managed rule groups) and TLS via **ACM**. The origin is never publicly exposed; CloudFront is the only public surface. Security headers (HSTS, CSP without unsafe-inline scripts, X-Content-Type-Options, frame-ancestors) are applied via response headers policy.
2. **Authentication.** The application authenticates users through **Amazon Cognito federated to the enterprise identity provider** (OIDC/SAML federation — Cognito brokers; the enterprise directory remains the source of truth for identities, MFA, and conditional access). The flow is **Authorization Code with PKCE** only; implicit flow is disabled on the app client. Access tokens are short-lived (≤ 60 minutes) and held in memory per SDK guidance — never in persistent browser storage.
3. **API traffic.** All dynamic data flows through **Amazon API Gateway**, which validates tokens (Cognito authorizer), enforces an explicit CORS allow-list (no wildcards), throttles, and routes to backend services. Backends are not directly reachable from the browser.
4. **Observability.** CloudFront, WAF, API Gateway, and Cognito logs flow to **Amazon CloudWatch** and onward to the enterprise logging destination; the reference implementation deploys a standard alarm pack and an availability canary.
5. **Delivery.** Infrastructure is provisioned exclusively through the reference implementation Terraform module; application deployment runs through the enterprise pipeline with SAST/SCA gates.

**UI framework is a variation, not the pattern:** React (default), Angular, or plain HTML/JavaScript are all supported — hosting, security, and operational design are identical; only the build step differs. The pattern is named by its design, not by a framework.

## Diagram

*Diagram to be produced for Confluence. It shows:* end user (browser, untrusted zone) → CloudFront + WAF → Amplify Hosting origin (shell path); browser ↔ Cognito ↔ enterprise IdP (federation, Auth Code + PKCE); browser → API Gateway (token validated) → backend services (private); log flows to CloudWatch → enterprise logging. Trust boundary drawn at CloudFront/API Gateway.

## Use Cases

1. **Internal workforce applications** — browser-delivered business tools authenticating via the enterprise directory (workforce federation)
2. **Customer-facing web applications** — external users via the customer identity configuration of the same federation approach
3. **Application modernization** — replacing server-rendered legacy UIs with client-rendered applications over new or existing APIs
4. **Rich UI over existing enterprise APIs** — new experiences composed on already-governed API products

## Goals & Benefits

1. **Compliant by default** — edge WAF, TLS, federated identity, PKCE flow, private origins, and logging are delivered by the reference implementation, not re-decided per project
2. **Reduced review effort** — security-relevant decisions are pre-made in the approved pattern; project review focuses on business-specific risk *(the framework's reference-implementation objective)*
3. **Independent scaling and availability** — shell delivery scales at the edge regardless of API load; API capacity scales independently of content delivery
4. **Faster starts** — teams begin at business capability, not undifferentiated assembly

## Limitations

1. **Not for server-side rendering** — SEO-critical or first-paint-critical applications need a server-rendered approach (out of scope here)
2. **Not for unauthenticated static content** — a site with no APIs and no login should use the Static Content Web Site pattern (simpler, cheaper); see When To Use
3. **Cognito constraints** — brokered federation adds a component and its service quotas to the identity path; token customization is bounded by Cognito's capabilities *(the design trade-off accepted for native API Gateway integration — see Appendix ADR)*
4. **Amplify Hosting constraints** — build/runtime customization is bounded by Amplify's managed pipeline; workloads needing low-level CDN control use the documented S3-private-origin + CloudFront variation
5. **Browser as untrusted runtime** — the pattern cannot protect secrets in the client because no client secret exists by design; anything requiring confidential client credentials belongs behind the gateway

## Components/Services

AWS Amplify Hosting (shell build & hosting) · Amazon CloudFront (edge delivery) · AWS WAF (edge inspection) · AWS Certificate Manager (TLS) · Amazon Cognito (identity brokering, federated to enterprise IdP) · Amazon API Gateway (API mediation) · Amazon Route 53 (DNS) · Amazon CloudWatch (telemetry)

*Service mechanics, quotas, and pricing live in the linked **Service Offering** pages — deliberately not restated here. This document records the design: how and why these services are composed.*

## When To Use

**Use this pattern when:** the application is browser-rendered, users authenticate against the enterprise IdP, and dynamic data flows through APIs called from the browser.

**Do not use when:** content is identical for all users with no authenticated APIs → **Static Content Web Site** pattern; server-side rendering is required → server-rendered pattern *(to be authored)*; the client is a native mobile app → mobile pattern family.

**Boundary test:** does the browser authenticate users or call APIs? Yes → this pattern. No → static pattern.

## ⭑ Related Patterns

| Relationship | Pattern | Level |
|---|---|---|
| Realizes | Single Page Web App | Solution Pattern |
| Inherits from (via parent) | Static Content Hosting; Gateway; Federated Identity | Architecture Patterns |
| Inherits from (via parent) | N-Tier (Web-Based) | Architecture Style |
| Sibling (same parent, different CSP) | Single Page Web App Hosting on Azure *(planned)* | EDP |
| Adjacent (boundary) | Static Content Web Site → its AWS EDP *(candidate)* | Solution Pattern / EDP |

*This populated lineage section is the framework's phase-1 ask of every EDP: traceability from implementation guidance back to approved architectural intent.*

## Security

**Shared responsibility:** AWS secures the underlying services (security *of* the cloud); this pattern defines Canada Life's configuration responsibilities (security *in* the cloud) — identity, access, network exposure, data protection, logging.

**Pattern security posture:**
- Only public surfaces: CloudFront (shell) and API Gateway (APIs), both WAF-protected and TLS 1.2+
- Origins private (Amplify/S3 origin access restricted to CloudFront); backends reachable only via API Gateway
- Authentication federated to the enterprise IdP — no local credential store; enterprise MFA and conditional access apply; Authorization Code + PKCE only; access tokens ≤ 60 min, in-memory only
- CSP forbids unsafe-inline scripts; explicit CORS allow-list; no data or secrets in the shell (shell is public-classification content by design)
- All service logs to enterprise logging; WAF in prevention mode

**Canada Life security controls:** DLP standard · InfraSec standard · AppSecOp standard · Data Retention and Disposal standard *(per MetricStream; links in Appendix)*. **BISO is a consulted reviewer of this pattern** per the Framework v1.4 RACI update.

## Cost Model

Chargeback (if any) to business unit deploying this pattern. Cost drivers: CloudFront data transfer, API Gateway requests, Cognito MAU, Amplify build minutes — unit costs per the linked Service Offering pages.

## Deployment Strategy

Provisioning exclusively via the reference implementation Terraform module: `https://gitlab.com/canada-life/TEP/cloud-platform-engineering/cloud/aws/library/platform-aws-tflib-spa-hosting` *(placeholder — create alongside this pattern, mirroring the existing tflib structure, e.g., platform-aws-tflib-transfer-family-webapp)*. Application deployment via the enterprise pipeline template with SAST/SCA gates. Portal-created production resources are a deviation requiring exception.

## Review History

| Version # | Changes | Solution Architect | Review Date | Reviewer(s) | Approved Date | Approver(s) | Notes |
|---|---|---|---|---|---|---|---|
| 0.1 | Draft — authored as framework end-to-end demonstration | *(to assign)* | | | | | Lineage fields included per Pattern Framework v1.4 |

## Appendix

**References:** Canada Life Pattern Framework v1.4 · Parent Solution Pattern: Single Page Web App · CL applicable standards (MetricStream) · AWS documentation: Amplify Hosting, CloudFront, WAF, API Gateway, Cognito federation · ADR *(to record)*: Cognito-brokered vs direct enterprise IdP integration — **validate with Identity Engineering before approval**; if direct integration is preferred, the lineage and solution pattern are unaffected (delegated L4 decision only).

**Real-world grounding — validation checklist before socialization:**
1. Confirm a current or upcoming AWS-hosted web application to cite as first consumer *(your July 3 action item: search delivery records for business solutions matching this pattern)*
2. Confirm TBM taxonomy values against the value list
3. Assign actual EDP-<N> from the catalog (owner: Bassem Masri)
4. Confirm identity direction (Cognito broker vs direct) with Identity Engineering and BISO
5. Azure sibling: validate the Coveo Atomic search UI hosting evaluation (DAAP) as the real Azure-side requirement
