# ARCHITECTURE STYLE — N-Tier (Web-Based) Architecture

*Authored on the approved Architecture Style template (v1.3 structure). Lifecycle: Proposed.*

## 1. Pattern Metadata

**Pattern Name:** N-Tier (Web-Based) Architecture
**Pattern Category:** Architecture Style
**Version:** 0.1
**Status:** Proposed
**Approval Date:** —
**Owner / Maintainer:** Enterprise Architecture (to assign)
**Labels:** N-Tier, Client-Server, Web, Separation of Concerns, Presentation Tier

## 2. Problem Statement

*Describe the architectural problem or limitation this architecture style is intended to address, without describing the solution.*

When a system's presentation, business logic, and data concerns are built and deployed as one undifferentiated block, every change carries the risk profile of the whole. User interface changes require re-testing business logic; data model changes ripple into presentation code; the entire system must scale, fail, and be secured as one unit. As systems grow and multiple teams work on them, this entanglement slows delivery, widens the blast radius of defects, and makes it impossible to apply different security postures, scaling strategies, or technology choices to parts of the system that have fundamentally different characteristics — for example, a public-facing user interface versus an internal data store.

### 2.1 Architectural Intent

*What does this style bring to solve that challenge?*

N-Tier Architecture organizes a system into **logically and physically separated tiers**, each with a distinct responsibility — typically presentation (client), application/business logic, and data. Tiers interact only through defined interfaces over standard protocols; in the web-based variant, clients interact with server tiers over HTTP(S).

Separation into tiers allows each tier to be **developed, deployed, scaled, secured, and replaced independently** within the constraints of its interfaces. The presentation tier can be optimized for user experience and delivered globally; business logic can scale with processing demand; data tiers can be hardened and isolated. Tier boundaries become natural security perimeters and natural team boundaries.

## 3. Context & Applicability (When to Use)

**Context**

Web-based N-Tier architecture is the dominant style for business applications delivered through a browser. It fits environments where user-facing functionality must be broadly accessible over standard web protocols while business logic and data remain protected inside controlled network zones — the standard posture for a regulated financial institution.

This style is commonly adopted where:
- Applications serve users through **browsers or web clients** without installing software
- **Different security postures** are required for user-facing versus data-holding components
- Presentation and backend components **change at different speeds** and are owned by different teams
- Components must **scale independently** (many users, comparatively fewer heavy backend operations)

**Applicability**

- Business applications delivered through the browser (internal or customer-facing)
- Systems where a clear trust boundary must exist between the client and enterprise data
- Solutions expected to evolve their user experience faster than their backend contracts
- The degenerate single-tier case — presentation tier only, no application or data tier — covers pure static web content

## 4. Architecture Style Description and Conceptual Diagram

### 4.1 Architecture Style Description

**4.1.1 Key Concepts**

A **tier** is a logically separated, independently deployable responsibility boundary (distinct from a *layer*, which is a code-organization concept within one deployable unit). Tiers communicate only through defined interfaces over the network. The client tier is **untrusted**: anything executing on a user's device or browser is outside the organization's control, and trust is established per request through authentication and validation at tier boundaries.

**4.1.2 Core Components**

- **Client / presentation tier** — renders the user experience; in web-based systems, executes in the browser
- **Application tier** — exposes business capability through defined interfaces (typically APIs); enforces authorization and business rules
- **Data tier** — persists and protects enterprise data; reachable only from the application tier

**4.1.3 Interaction Model**

Clients initiate requests over standard web protocols (HTTPS); server tiers respond. Interactions across the client boundary are **stateless** — each request carries what is needed (such as tokens) to establish identity and context. State that matters lives in the data tier, not in the connection.

**4.1.4 Architecture Variants**

- **Single-tier (web):** presentation only — static content delivered to browsers with no application or data tier
- **Two-tier:** client interacting directly with a data-capable backend
- **Three-tier:** the canonical presentation / application / data separation
- **N-tier:** additional tiers for mediation and cross-cutting concerns (edge delivery, gateways, integration tiers)

**4.1.5 Rendering Variations (web-based)**

- **Server-rendered:** the application tier produces presentation markup per request
- **Client-rendered (Single Page Web App):** the presentation tier executes in the browser as an application, with all dynamic interaction via APIs — see the related Solution Pattern
- **Static:** presentation content is fixed and identical for all users

### 4.2 Conceptual Architecture Diagram

**Diagram 1 — Tiered interaction model.** *Diagram shows:* client tier (browser), application tier (APIs), data tier; requests flowing client → application → data over defined interfaces; trust boundary marked between client tier and server tiers.
**Purpose:** illustrates that the client is outside the trust boundary, that tiers interact only through interfaces, and that data is never directly reachable from the client.

**Diagram 2 — Rendering variants.** *Diagram shows:* the three web rendering variants (server-rendered, client-rendered/SPA, static) as specializations of the same tiered model.
**Purpose:** shows that the variants differ in *where presentation executes*, while the tier boundaries and trust model remain constant — which is why they share this style but diverge into different Solution Patterns.

## 5. Considerations (including benefits) and trade-off

**Benefits**

**Independent evolution and scaling** — tiers change, deploy, and scale on their own cadence within stable interface contracts.
**Security by boundary** — tier boundaries are enforceable perimeters; the untrusted client tier never touches data directly, which aligns naturally with regulatory expectations for protecting enterprise data.
**Team alignment** — presentation, application, and data responsibilities map cleanly to team ownership.
**Technology fit per tier** — each tier can use technology suited to its job rather than one compromise stack.

**Trade-offs / Constraints**

**Network hops and latency** — every tier boundary adds a network interaction; chatty interfaces multiply latency.
**More operational surface** — multiple deployable units mean more things to provision, monitor, patch, and secure than a monolith.
**Interface discipline required** — tier independence holds only while interface contracts are respected; undisciplined coupling through shared data or leaked internals silently collapses the benefits.
**Distributed failure modes** — partial availability (one tier degraded) must be designed for, not discovered.

## 6. Reference Implementations (Links Only)

*Architecture Styles are conceptual and do not have direct implementations. Realizations exist through Architecture Patterns and Solution Patterns that apply tiered principles.*

**Links to Related Architecture Patterns**
- Static Content Hosting *(this pack)*
- Gateway *(this pack)*
- Federated Identity *(this pack)*

**Related Solution Patterns**
- Single Page Web App *(this pack)*
- Static Content Web Site *(candidate — the single-tier demonstrator)*

## 7. References

- Canada Life Pattern Framework v1.4 (hierarchy, abstraction bands, governance)
- Internal Enterprise Architecture documentation
- Industry references on N-tier and web application architecture (Microsoft Azure Architecture Center, AWS Well-Architected)

## 8. Changelog

| Version | Date | Author | Change Description |
| --- | --- | --- | --- |
| v0.1 | 2026-07-14 | S. Kumar (Portfolio Architecture) | Initial proposal — authored for the framework end-to-end demonstration |
