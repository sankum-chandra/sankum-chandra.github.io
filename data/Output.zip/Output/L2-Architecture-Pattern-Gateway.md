# ARCHITECTURE PATTERN — Gateway

*Authored on the approved Architecture Pattern template (v1.3 structure). Lifecycle: Proposed.*

## 1. Pattern Metadata

**Pattern Name:** Gateway
**Pattern Category:** Architecture Pattern
**Version:** 0.1
**Status:** Proposed
**Approval Date:** —
**Owner / Maintainer:** Enterprise Architecture (to assign)
**Labels:** API, Gateway, Mediation, Policy Enforcement, Integration, Entry Point

## 2. Problem Statement

*Describe the technical problem this pattern addresses. Explain why the problem occurs and the impact of not using the pattern.*

When client applications — browsers, mobile apps, partner systems — call backend services directly, every service independently carries the same set of cross-cutting responsibilities: authenticating callers, validating tokens, enforcing rate limits, handling CORS, managing versioning, and emitting consistent telemetry. As the number of clients and services grows, the consequences compound:

- **Scattered, inconsistent policy** — each service implements authentication and throttling its own way; a policy change (for example, a new token validation rule) must be rolled out N times and verified N times
- **Coupling to topology** — clients bind to individual service locations and shapes; restructuring backends breaks consumers
- **Multiplied attack surface** — every directly reachable service is a separately exposed, separately reviewable public endpoint
- **No single point of observation or control** — traffic, errors, and abuse patterns are visible only per-service, never for the interaction surface as a whole

### Solution

**The Gateway pattern introduces a single governed entry point through which all client-to-service traffic flows.** The gateway mediates: it authenticates and validates tokens once, enforces throttling, CORS, and routing policy uniformly, presents stable versioned interfaces to clients while backends evolve behind it, and emits complete telemetry for the entire interaction surface. Backends cease to be publicly reachable; policy ceases to be a per-service reimplementation and becomes configuration at one enforcement point.

## 3. Context & Applicability (When to Use)

**Context**

The Gateway pattern applies wherever services are consumed by clients outside their own trust context — browser applications (which are untrusted by definition), mobile clients, partner integrations, or cross-domain consumers inside the enterprise. In a tiered architecture it forms the controlled boundary between the client tier and the application tier: the one place where an untrusted caller becomes an authenticated, policy-checked request.

**Applicability**

Use this pattern when:
- Services are consumed by **untrusted or external-to-domain clients** (browsers, mobile, partners)
- **Uniform policy** (authentication, throttling, CORS, versioning) must hold across multiple services
- Backends must be able to **evolve without breaking consumers**
- A **single point of security enforcement and observation** is required for the interaction surface

Do **not** use this pattern when:
- Traffic is purely internal service-to-service within one trust and ownership boundary, where the gateway adds a hop without adding governance value (service-to-service concerns are a different pattern space)
- A single, simple, internally consumed service would gain nothing but latency from mediation

## 4. Pattern Description and Architecture Diagram

The Gateway is a mediation component standing between clients and backend services, owning the cross-cutting concerns of the interaction surface so that backends own only their domain logic.

### 4.1 Core Concepts

**Single entry point** — all in-scope client traffic traverses the gateway; backends are not directly reachable from clients. The gateway is therefore part of the security perimeter and is governed as such.
**Policy enforcement point** — authentication/token validation, authorization checks, rate limiting, CORS, request/response validation, and header policy are applied once, uniformly, as configuration.
**Interface stability (façade)** — the gateway presents versioned, stable interfaces to clients while routing to backends that can be restructured, replaced, or relocated behind it.
**Complete observability** — because everything crosses one point, the gateway yields whole-surface telemetry: traffic, latency, errors, and abuse patterns per client and per interface.

### 4.2 Architectural Flow

- A client presents a request (with credentials or tokens where required) to the gateway
- The gateway authenticates/validates, applies policy (throttling, CORS, validation), and rejects non-conforming traffic at the boundary
- Conforming requests are routed to the appropriate backend over private connectivity
- Responses return through the gateway, which applies response policy and records telemetry

### 4.3 Variants

**Edge gateway** — fronts an entire interaction surface for external/untrusted clients (the variant composed by the Single Page Web App solution pattern).
**Domain/internal gateway** — mediates a bounded set of services for cross-domain consumers inside the enterprise.
**Backend-for-Frontend (BFF)** — a client-type-specific gateway shaping interfaces for one frontend's needs; a specialization to be applied deliberately, as each BFF is an additional surface to govern.

### 4.4 Diagram (Conceptual Reference)

*A conceptual diagram illustrates:* multiple clients → gateway [authenticate · validate · throttle · route] → backend services (private); trust boundary at the gateway; telemetry emitted from the gateway; no client-to-backend path.

**Explanation:** the essential property is the *absence* of any path from client to backend that bypasses the gateway. Clients see stable interfaces and one boundary; backends see only authenticated, policy-conforming traffic from a known mediator. Policy and observation exist exactly once.

## 5. Considerations (including benefits) and Trade off

**Benefits**

**Uniform, centrally evolvable policy** — security and traffic policy is configuration at one point, not code in N services; changes deploy once
**Reduced attack surface** — one hardened public entry replaces many exposed services
**Consumer/backend decoupling** — versioned façade lets backends evolve without breaking clients
**Whole-surface observability** — complete traffic visibility enables monitoring, audit, and abuse detection that per-service logging cannot provide

**Trade-offs and Constraints**

**Critical dependency** — the gateway sits in the path of everything; it must be engineered for availability and scale commensurate with the entire surface it fronts
**Latency hop** — mediation adds a network traversal; chatty client designs magnify it
**Configuration is the perimeter** — gateway policy errors are security errors; policy must be governed, versioned, and tested like code
**Over-centralization risk** — business logic migrating into the gateway creates a new coupling point; the gateway mediates, it does not implement domain behavior
**Gateway sprawl** — undisciplined proliferation of gateways/BFFs recreates the scattered-policy problem one level up

## 6. Reference Implementations (Links Only)

*This architecture pattern is technology-agnostic and does not prescribe specific platforms or products.*

**Related Solution Patterns**
- Single Page Web App *(this pack — composes this pattern for all browser-originated API traffic)*
- Mobile application backend, B2B partner API *(candidates — same composition role)*

## 7. References

- Canada Life Pattern Framework v1.4
- Industry references: API gateway and Backends-for-Frontends patterns (Microsoft Azure Architecture Center, AWS guidance)
- EA internal documentation

## 8. Changelog

| Version | Date | Author | Change Description |
| --- | --- | --- | --- |
| v0.1 | 2026-07-14 | S. Kumar (Portfolio Architecture) | Initial proposal — completes the Single Page Web App L3 composition |
