# ARCHITECTURE PATTERN — Federated Identity

*Authored on the approved Architecture Pattern template (v1.3 structure). Lifecycle: Proposed.*

## 1. Pattern Metadata

**Pattern Name:** Federated Identity
**Pattern Category:** Architecture Pattern
**Version:** 0.1
**Status:** Proposed
**Approval Date:** —
**Owner / Maintainer:** Enterprise Architecture (to assign)
**Labels:** Identity, Authentication, OIDC, OAuth 2.0, SSO, Token-Based, IdP

## 2. Problem Statement

*Describe the technical problem this pattern addresses. Explain why the problem occurs and the impact of not using the pattern.*

When each application authenticates users against its own credential store, identity fragments across the portfolio, and every consequence is a security and governance liability:

- **Multiplied attack surface** — every local credential store is a separately breachable, separately hardened password database
- **Ungovernable identity lifecycle** — joiner-mover-leaver events, MFA requirements, and access policies must be enforced per application; in practice they are enforced inconsistently or not at all, and departed users retain orphaned accounts
- **No enterprise view** — sign-in activity, credential risk, and access cannot be observed or audited centrally, which is untenable under regulatory expectations for a financial institution
- **User burden** — one identity per application produces password fatigue and its predictable coping behaviors (reuse, weak passwords)

### Solution

**Federated Identity delegates authentication to a trusted enterprise identity provider (IdP), so that applications never handle credentials at all.** Applications establish a trust relationship with the IdP and consume standards-based security tokens (OIDC/OAuth 2.0, SAML) that assert who the user is and what has been verified. Authentication strength (MFA, conditional access), lifecycle governance, and audit exist once — at the IdP — and apply automatically to every federated application. The application's job reduces to validating tokens and making authorization decisions from asserted claims.

## 3. Context & Applicability (When to Use)

**Context**

Federated Identity applies to every user-facing application in an enterprise that maintains a central identity authority — for the workforce, and equally for customer identity through a customer-facing configuration of the same model. It is the identity half of the tiered trust model: the untrusted client tier never holds credentials or secrets; trust is established per request through tokens issued by the enterprise authority and validated at controlled boundaries (typically at a Gateway).

Client type shapes the flow, not the pattern: **confidential clients** (server-side applications) can hold secrets and use flows that rely on them; **public clients** (browser applications, mobile apps) cannot hold secrets, and must use flow classes designed for that reality — with proof mechanisms replacing secrets and short-lived tokens limiting exposure.

**Applicability**

Use this pattern when:
- Any application authenticates **human users** (workforce or customers)
- **Enterprise identity governance** — MFA, conditional access, joiner-mover-leaver, central audit — must apply to the application
- **Single sign-on** across the portfolio is expected
- The client is **public** (browser, mobile) and must authenticate without ever holding a credential or secret

Do **not** use this pattern when:
- The caller is a **workload, not a human** — machine-to-machine authentication is the related workload-identity pattern space, not user federation
- No user authentication exists at all (anonymous public content)

## 4. Pattern Description and Architecture Diagram

Federated Identity restructures authentication from something every application *does* into something every application *consumes*.

### 4.1 Core Concepts

**Identity provider as sole authority** — one system authenticates users, enforces authentication strength, and issues tokens; applications hold a trust relationship with it, never with user credentials
**Tokens and claims** — short-lived, signed tokens carry verified assertions (identity, authentication context, granted scopes); applications validate signature, issuer, audience, and lifetime, then decide authorization from claims
**Client registration** — each application is a registered, individually governed client of the IdP, with its own permitted flows, scopes, and redirect boundaries — making application access itself an auditable object
**Public-client discipline** — browser and mobile clients use authorization-code flows with proof mechanisms (no embedded secrets), short token lifetimes, and non-persistent token storage; legacy flows that leak tokens through the front channel are prohibited
**Federation across authorities** — IdPs can chain trust (brokering), allowing one authority to front another; the enterprise directory remains the source of truth wherever brokering is used

### 4.2 Architectural Flow

- The application redirects an unauthenticated user to the IdP
- The IdP authenticates the user under enterprise policy (credentials, MFA, conditional access) — the application never sees credentials
- The IdP issues tokens to the application through the flow class appropriate to its client type
- The application presents tokens with each request; validation occurs at controlled boundaries (e.g., the Gateway); authorization derives from claims
- Token expiry and refresh follow IdP policy; revocation and lifecycle events take effect centrally

### 4.3 Variants

**Workforce identity** — employees and contractors against the enterprise directory
**Customer identity (CIAM)** — external users through a customer-facing configuration: same pattern, different population, registration, and assurance policies
**Brokered federation** — an intermediary identity service fronts the enterprise IdP where a platform requires it; a realization choice made at the engineering level, with the enterprise directory remaining authoritative

### 4.4 Diagram (Conceptual Reference)

*A conceptual diagram illustrates:* user ↔ application (untrusted client tier); application → redirect → IdP [credentials · MFA · policy]; IdP → tokens → application; application → token-bearing requests → validation boundary (Gateway) → services; central audit at the IdP.

**Explanation:** the essential properties are that credentials exist in exactly one place (the IdP) and that every downstream trust decision derives from validated tokens. The application is a consumer of identity, not a manager of it; removing a user at the IdP removes them everywhere at token expiry.

## 5. Considerations (including benefits) and Trade off

**Benefits**

**Credential surface collapses to one governed system** — no local password stores anywhere in the portfolio
**Governance by construction** — MFA, conditional access, joiner-mover-leaver, and audit apply to every federated application automatically, satisfying regulatory expectations centrally rather than per application
**Single sign-on** — one authenticated session serves the portfolio
**Applications simplify** — authentication logic reduces to token validation and claims-based authorization

**Trade-offs and Constraints**

**IdP in the critical path** — identity provider availability bounds the availability of every federated application; the IdP must be engineered and operated accordingly
**Token discipline is permanent** — short lifetimes, correct storage (never persistent in public clients), and validation rigor are ongoing obligations; the pattern's security reduces to these disciplines at the edges
**Claims and scope design require governance** — poorly designed claims either starve applications of authorization context or leak more identity data than necessary
**Federation adds moving parts** — where brokering is used, trust chains, metadata, and certificate lifecycles must be operated; broker versus direct integration is a deliberate engineering decision to be recorded per realization

## 6. Reference Implementations (Links Only)

*This architecture pattern is technology-agnostic and does not prescribe specific platforms or products.*

**Related Solution Patterns**
- Single Page Web App *(this pack — composes this pattern for user authentication in a public client)*
- Mobile application backend, B2B partner access *(candidates — same composition role, different client types)*

## 7. References

- Canada Life Pattern Framework v1.4
- Industry references: Federated Identity pattern (Microsoft Azure Architecture Center); OAuth 2.0 / OIDC current best practice for public clients
- EA internal documentation; identity standards per MetricStream

## 8. Changelog

| Version | Date | Author | Change Description |
| --- | --- | --- | --- |
| v0.1 | 2026-07-14 | S. Kumar (Portfolio Architecture) | Initial proposal — completes the Single Page Web App L3 composition |
