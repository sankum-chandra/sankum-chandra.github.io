# SOLUTION PATTERN — Single Page Web App

*Authored on the approved Solution Pattern template (v1.3 structure). Lifecycle: Proposed. Named per the Pattern Framework v1.4 hierarchy illustration, which cites "Single Page Web App" as a Solution Pattern example.*

## 1. Pattern Metadata

**Pattern Name:** Single Page Web App
**Pattern Category:** Solution Pattern
**Version:** 0.1
**Status:** Proposed
**Approval Date:** —
**Owner / Maintainer:** Enterprise Architecture / Design Authority (per v1.4 RACI for solution pattern domain)
**Labels:** Web Application, SPA, Client-Rendered, API, Federated Identity, Edge Delivery

## 2. Problem Statement

*Describe the technical problem this solution pattern addresses. Explain why the problem occurs and the impact of not using the pattern.*

Browser-rendered applications backed by APIs are the dominant shape of modern business application delivery. Building one requires the same set of decisions every time: how the application shell reaches the browser, how API traffic is mediated and secured, how users authenticate, how tokens are handled in an untrusted client, and how the whole assembly is observed.

Because no approved end-to-end composition exists, each delivery team re-makes these decisions independently. The consequences compound across the portfolio:

- **Inconsistent security postures** — different token storage choices, different CORS policies, different (or absent) edge protection, each a separately reviewable risk
- **Repeated review effort** — security and architecture review the same decisions again for every application, since nothing is pre-approved
- **No lineage** — implementations cannot be traced to approved architectural intent, so there is no way to confirm the portfolio follows approved approaches (a direct gap against the Pattern Framework's traceability objective)
- **Slow starts** — teams spend early sprints on undifferentiated assembly rather than business capability

### 2.1 Solution

The Single Page Web App solution pattern defines the **approved end-to-end composition** for applications whose presentation logic executes in the browser and whose every dynamic interaction is an authenticated API call.

It composes three architecture patterns into one solution structure: **Static Content Hosting** delivers the application shell through edge-secured, storage-backed hosting; **Gateway** mediates all API traffic through a single governed entry point; **Federated Identity** delegates authentication to the enterprise identity provider using standards-based token flows. The composition fixes the decisions that must be uniform (trust boundaries, token flow class, single API entry point, edge security) while leaving genuinely local decisions (UI framework, API design, business logic) to delivery teams.

## 3. Context & Applicability (When to Use)

**Context**

This solution pattern applies to business applications delivered through the browser — internal workforce applications and external customer-facing applications alike — within a web-based N-Tier architecture. In these applications the browser is an application runtime, not a document viewer: the presentation tier executes on the user's device, which is by definition **outside the organization's trust boundary**. Every architectural decision in the pattern follows from that fact: the shell is treated as public content (delivered via Static Content Hosting), data is never embedded in the shell, all data access is authenticated per request (Federated Identity) through one governed entry point (Gateway).

**Applicability**

Use this solution pattern when:
- The user experience is **browser-rendered** with dynamic, per-user interaction
- Users **authenticate** against the enterprise identity provider (workforce or customer)
- All dynamic data flows through **APIs** called from the browser

Do **not** use when:
- Content is identical for all users with no authenticated APIs → *Static Content Web Site* solution pattern (Static Content Hosting alone)
- Server-side rendering is required (SEO-critical, first-paint-critical) → a server-rendered solution pattern
- The client is a native mobile application → mobile solution pattern family

**Boundary test:** does the browser authenticate users or call APIs? Yes → this pattern. No → Static Content Web Site.

## 4. Pattern Description and Architecture Diagram

### 4.1 Architecture Diagram

Diagram Type: **Single Page Web App — Solution Composition Diagram**

*Diagram shows:* browser (untrusted zone) → edge delivery serving the application shell from private origin storage [Static Content Hosting]; browser ↔ enterprise identity provider via standards-based token flow [Federated Identity]; browser → API gateway presenting tokens → backend services [Gateway]; telemetry from all components to enterprise observability; trust boundary drawn at the edge and gateway.

### 4.2 Pattern Description

The solution operates as follows. The browser retrieves the **application shell** — markup, scripts, styles — from edge-secured static hosting; the shell is public-classification content containing no data and no secrets. The application then directs the user to **authenticate with the enterprise identity provider** using a standards-based flow appropriate to a public client; the identity provider remains the sole authority for credentials, and the application never handles them. Holding tokens (in memory, never in persistent browser storage), the application makes **API calls exclusively through the gateway**, which validates tokens, enforces policy (throttling, CORS allow-lists, routing), and mediates access to backend services. Backends are never directly reachable from the browser.

The composition assigns each concern to exactly one composed pattern:

- **Shell delivery → Static Content Hosting:** availability and performance of the user experience decoupled from application health; edge WAF and TLS on the content path
- **Data access → Gateway:** one governed entry point; uniform authentication enforcement, versioning, and observability for all API traffic
- **Identity → Federated Identity:** no local credential stores; enterprise identity governance (MFA, conditional access, joiner-mover-leaver) applies automatically

The orchestrating logic of the solution — session flow, token refresh, route protection — lives in the shell application itself, built by the delivery team within the constraints above.

## 5. Considerations (including benefits) and Tradeoff

**Benefits**

**Compliant by default** — the security-relevant decisions (trust boundaries, token flow class, single entry point, edge inspection) are made once, here, and inherited by every consumer; review effort concentrates on business-specific risk
**Portfolio consistency with local freedom** — UI framework and API design remain team choices; what's uniform is exactly what must be uniform
**Independent scaling and availability** — shell delivery scales at the edge irrespective of API load; a degraded backend does not take down the user experience shell
**Lineage** — implementations reference this pattern; this pattern references its composed architecture patterns and parent style; the traceability chain the framework requires exists by construction

**Trade-offs / Constraints**

**The browser is an untrusted runtime** — token discipline (in-memory storage, short lifetimes), content security policy, and dependency hygiene in the shell are permanent obligations, not setup tasks
**Composition inherits three dependency surfaces** — identity provider availability, gateway availability, and edge availability all sit in the critical path; each composed pattern's trade-offs apply
**Initial-load weight** — the shell downloads before first interaction; applications with severe first-paint requirements may need the server-rendered alternative
**Eventual re-platforming boundary** — consumers must know the adjacent patterns (static-only below it, server-rendered beside it) to avoid stretching this one

## 6. Solution Implementations

### 6.1 Technology Mapping (Concrete)

| Component | AWS Standard Service | Azure Standard Service |
| --- | --- | --- |
| Application shell hosting (origin) | AWS Amplify Hosting *(or S3 private origin)* | Azure Static Web Apps *(or Blob Storage static hosting)* |
| Edge delivery & TLS | Amazon CloudFront + ACM | Azure Front Door (Premium) + managed certificates |
| Edge security (WAF) | AWS WAF (managed rule groups) | Front Door WAF policy (managed ruleset) |
| API mediation | Amazon API Gateway | Azure API Management |
| Identity / token brokering | Amazon Cognito **federated to enterprise IdP** | Microsoft Entra ID (native) |
| DNS | Amazon Route 53 | Azure DNS |
| Observability | Amazon CloudWatch → enterprise logging | Azure Monitor / Log Analytics → enterprise logging |
| Delivery pipeline | Enterprise CI/CD with IaC (Terraform) | Enterprise CI/CD with IaC (Terraform) |

**Component Mapping Explanation (Brief, EA-Level)**

- **Shell hosting + edge + WAF** realize Static Content Hosting for the application shell: private origin, edge-only exposure, inspection and TLS at the edge
- **API mediation** realizes Gateway: the single governed entry for all browser-originated API traffic, enforcing token validation and explicit CORS allow-lists
- **Identity** realizes Federated Identity: on Azure, Entra ID serves directly; on AWS, Cognito acts as broker federated to the enterprise IdP so that the enterprise directory remains the source of truth *(broker-vs-direct is an engineering decision recorded in the EDP)*
- **Observability & pipeline** are enterprise cross-cutting capabilities applied to every component

*Both CSPs are enterprise-approved; the same solution structure maps to standard services on each. One Engineering Design Pattern per CSP realizes this mapping concretely.*

### 6.2 Reference Implementations (Links Only)

- **AWS implementation:** EDP — Single Page Web App Hosting on AWS *(this pack — see L4 document)*
- **Azure implementation:** EDP — Single Page Web App Hosting on Azure *(this pack — authored on the proposed enhanced EDP format; candidate real-world consumer: Coveo Atomic search UI hosting evaluation in DAAP — to be validated)*
- GitLab reference implementation repositories *(links per EDP)*

## 7. References

- Canada Life Pattern Framework v1.4 (hierarchy example naming "Single Page Web App" at Solution Pattern level)
- Related patterns in this lineage: N-Tier (Web-Based) Architecture Style; Static Content Hosting, Gateway, Federated Identity Architecture Patterns
- Industry references: Microsoft Azure Architecture Center (web application reference architectures), AWS Well-Architected
- ADRs: shell hosting service selection, identity brokering approach (per CSP EDP)

## 8. Changelog

| Version | Date | Author | Change Description |
| --- | --- | --- | --- |
| v0.1 | 2026-07-14 | S. Kumar (Portfolio Architecture) | Initial proposal — authored for the framework end-to-end demonstration |
