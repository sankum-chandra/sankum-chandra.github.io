# ENGINEERING DESIGN PATTERN TEMPLATE (Enhanced — Framework-Aligned)

*Base template for all Engineering Design Patterns. Structure: the current engineering EDP template, plus the additions (marked ⭑) that align it with Pattern Framework v1.4. Author guidance appears in italics — delete guidance before publishing. The ⭑ markers may be dropped once the enhanced template is adopted; during transition they show reviewers exactly what changed.*

## Table Of Contents
Pattern Summary · Problem Statement & Intent ⭑ · Description · How it works · Diagram · Use Cases · Goals & Benefits · Trade-offs & Constraints ⭑ · Inherited vs Delegated Decisions ⭑ · Variation Points ⭑ · Components/Services · When To Use · Pattern Lineage ⭑ · Security · Cost Model · Reference Implementation ⭑ · Review History · Appendix

---

## Pattern Summary

| Column Name | Column Value | Guidance |
|---|---|---|
| Pattern ID | EDP-<N> | *Next sequential number in the design pattern catalog (manually assigned per catalog owner)* |
| Pattern Name | | *Name the pattern by its design, not by a product or UI framework (e.g., "Single Page Web App Hosting on Azure", not "React on X"). Product names appear only where the product IS the design decision* |
| Type / Category / Name | | *Per TBM Taxonomy value lists (unchanged from current template)* |
| Cloud Specific / CSP | Yes–No / AWS, Azure | *Multi-CSP in one EDP only when the engineering design is genuinely identical across clouds; otherwise one EDP per CSP under the same parent Solution Pattern (declare siblings below)* |
| Service Offering(s) | | *Link every I&O Service Offering page this pattern references. Offerings are not patterns; their mechanics, quotas, and pricing live in the offering pages only* |
| Status | Proposed | ⭑ *Lifecycle states per Framework v1.4: Proposed / Approved / Under Review / Contained / Retired. State must be visible wherever the pattern is published* |
| ⭑ Pattern Lineage | | *Parent Solution Pattern → its composed Architecture Patterns → Architecture Style. Mandatory: an EDP with no approved parent Solution Pattern triggers either a Solution Pattern proposal (to bridge the gap) or reconsideration of the EDP* |
| ⭑ Sibling EDP(s) | | *Other EDPs realizing the same parent on a different CSP or platform; "none" is a valid entry* |
| Solution Architect | @ | |
| Reviewer(s) | @ ; ⭑ @BISO | ⭑ *BISO is Consulted wherever security implications exist — per the v1.4 RACI update, which is nearly always for cloud EDPs* |
| Approver(s) | ⭑ Design Authority | ⭑ *The Accountable governing body for EDPs per v1.4; named delegates must be published* |
| Approved Date | | |

---

## ⭑ Problem Statement & Intent

*New section. v1.4 approval criteria require every pattern to articulate problem and intent — and explicitly exclude service-only artifacts. Two short paragraphs:*

**Problem.** *The recurring engineering problem, and the impact of teams solving it independently (inconsistency, review burden, missing traceability). If you cannot state a problem that recurs across teams, this may be a service description or a one-project design — neither is an eligible pattern.*

**Intent.** *What the approved design guarantees: what becomes the default outcome, what review effort it removes, what it makes traceable.*

## Description

*3–6 sentences: the design in summary — the composed services, the trust model, and the parent Solution Pattern it realizes. A reader should know from this section alone whether they are in the right place.*

## How it works

*Numbered walk-through of the design in operation. Be concrete: named services, required configuration (TLS versions, flow types, policy modes), what is private and what is public. This is the buildable core — a delivery team should be able to build a conforming instance from this section plus the Reference Implementation.*

## Diagram

*Deployment/interaction diagram per catalog conventions. Must show trust boundaries explicitly, all public surfaces, and telemetry flows. Until produced, describe what the diagram shows.*

## Use Cases

*3–5 recurring situations this pattern serves. Recurring — a single project is not a use case list.*

## Goals & Benefits

*What consumers gain: compliance-by-default outcomes, review-effort reduction, scaling/availability properties, gap closure. Tie at least one benefit to the framework's objectives (traceability, reference implementations, reduced repeated review).*

## ⭑ Trade-offs & Constraints

*Upgrades the current "Limitations" section. v1.4 requires design trade-offs — the costs and boundaries of choosing this design: what it deliberately cannot do, what risks concentrate where, what disciplines it imposes on consumers. Service quotas and limits are NOT trade-offs; reference them to the Service Offering pages in one closing line.*

## ⭑ Inherited vs Delegated Decisions

*New section — the framework's inheritance model made explicit. This is also where engineering autonomy is visibly preserved: the delegated table is engineering's to own.*

**Inherited (constrained by lineage — deviation requires a governed exception via the Design Authority):**

| # | Constraint | Source (parent pattern or enterprise standard) |
|---|---|---|
| | | |

**Delegated (decided at this level — changing them changes this EDP only, never the lineage):**

| # | Decision | Rationale / ADR reference |
|---|---|---|
| | | |

*Rules: inherited constraints must be identical across sibling EDPs (drift on inherited items is a lineage defect and a review trigger); delegated decisions may legitimately differ per CSP; significant delegated decisions should be recorded as ADRs.*

## ⭑ Variation Points

*New section — declared flexibility prevents both rigidity and silent drift. Anything a consumer may vary must appear here with its allowed options and default; anything not listed is fixed.*

| # | Variation | Options | Default |
|---|---|---|---|
| | | | |

## Components/Services

*The composed services in one line each: service (role). Close with the standing rule:* Service mechanics, quotas, and pricing live in the linked Service Offering pages — deliberately not restated. This document records the design: how and why these services are composed.

## When To Use

**Use this pattern when:** *conditions, phrased as observable facts about the workload*

**⭑ Do not use when:** *each exclusion names the pattern to use instead — exclusions without alternatives strand consumers*

**⭑ Boundary test:** *one question that routes a consumer in or out (e.g., "does the browser authenticate users or call APIs?")*

**⭑ Scope:** *where this pattern is authoritative (enterprise-wide / domain / CSP). Reuse is intentional: single-use artifacts are not patterns (v1.4).*

## ⭑ Pattern Lineage

*Populates the current template's "Related Patterns" section with the framework's traceability requirement — the single most important addition.*

| Relationship | Pattern | Level |
|---|---|---|
| Realizes | | Solution Pattern |
| Inherits via parent | | Architecture Pattern(s) |
| Inherits via parent | | Architecture Style |
| Sibling (same parent, different CSP) | | EDP |
| Adjacent (boundary) | | *Patterns on the other side of the boundary test* |

## Security

**Shared responsibility:** *provider secures the underlying services; this pattern defines Canada Life's configuration responsibility.*

**Pattern posture:** *the security-relevant facts of the design in one paragraph: public surfaces, what is private, identity model, token/secret handling, logging destination, WAF mode.*

**Canada Life security controls:** *applicable standards by reference (per MetricStream — e.g., DLP, InfraSec, AppSecOp, Data Retention & Disposal). Standards are cited, never restated.* ⭑ *Record BISO's consultation.*

## Cost Model

*Chargeback statement plus the cost drivers of the design (which meters run). Unit costs live in the Service Offering pages.*

## ⭑ Reference Implementation

*Upgrades "Deployment Strategy" from optional links to a mandatory element. An EDP without a reusable implementation asset is guidance, not a pattern (the framework's reference-implementation objective).*

- **IaC module:** *GitLab tflib path — what it provisions, including diagnostics/alarm pack*
- **Pipeline template:** *build, security gates, deploy, availability-test registration*
- **Provisioning rule:** production resources exclusively via the module; portal-created production resources constitute a **deviation** requiring a governed **exception** *(v1.4 §9 terminology)*

## Review History

| Version # | Changes | Solution Architect | Review Date | Reviewer(s) | Approved Date | Approver(s) | Notes |
|---|---|---|---|---|---|---|---|
| 0.1 | Initial draft | | | | | | |

*Review triggers beyond cadence, per v1.4: significant platform/vendor changes, security/compliance changes, repeated exception requests, evidence of misuse, scope expansion, superior alternatives. EDPs are reviewed more frequently than higher pattern levels.*

## Appendix

**References:** *Framework v1.4 · parent Solution Pattern · sibling EDPs · applicable standards (MetricStream) · vendor documentation · ADRs recorded for delegated decisions*

---

### ⭑ Summary of additions relative to the current EDP template (for adoption discussion)
Problem Statement & Intent · Trade-offs & Constraints (replacing service-quota Limitations) · Inherited vs Delegated Decisions · Variation Points · Pattern Lineage (populating Related Patterns) · strengthened When To Use (do-not-use with alternatives, boundary test, scope) · v1.4 lifecycle Status values · Design Authority as approver, BISO as consulted reviewer · Reference Implementation as mandatory. **Everything else is the existing template, unchanged.**
