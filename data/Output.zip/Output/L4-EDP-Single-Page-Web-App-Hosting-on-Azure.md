# EDP — Single Page Web App Hosting on Azure

*Proposed well-formed Engineering Design Pattern for I&O consideration. Base structure: the current engineering EDP template (as used across the existing catalog, e.g., EDP-16). Sections and fields marked ⭑ are the proposed additions that close the gaps between the current template and Pattern Framework v1.4 — the ⭑ list is simultaneously the template-enhancement ask.*

## Table Of Contents
Pattern Summary · ⭑ Problem Statement & Intent · Description · How it works · Diagram · Use Cases · Goals & Benefits · ⭑ Trade-offs & Constraints (upgrades Limitations) · ⭑ Inherited vs Delegated Decisions · ⭑ Variation Points · Components/Services · When To Use (⭑ strengthened, incl. Scope) · ⭑ Pattern Lineage (populates Related Patterns) · Security · Cost Model · Reference Implementation (⭑ upgrades Deployment Strategy) · Review History · Appendix

---

## Pattern Summary

| Column Name | Column Value |
|---|---|
| Pattern ID | EDP-*(N — assign next sequential number in the design pattern catalog)* |
| Pattern Name | Single Page Web App Hosting on Azure |
| Type | Delivery *(suggested — confirm against TBM Taxonomy value list)* |
| Category | Development *(suggested — confirm)* |
| Name | Application Hosting *(suggested — confirm)* |
| Cloud Specific | Yes |
| Cloud Service Provider(s) | Azure |
| Service Offering(s) | Azure Static Web Apps *(offering page TBD)*, Azure Front Door Premium *(TBD)*, Azure API Management *(TBD)*, Microsoft Entra ID *(TBD)*, Azure DNS *(TBD)*, Azure Monitor / Log Analytics / Application Insights *(TBD)*, Azure Key Vault *(TBD)* |
| Status | PROPOSED ⭑ *(status values aligned to Framework v1.4 lifecycle: Proposed / Approved / Under Review / Contained / Retired)* |
| ⭑ Pattern Lineage | Solution Pattern: **Single Page Web App** → Architecture Patterns: **Static Content Hosting · Gateway · Federated Identity** → Architecture Style: **N-Tier (Web-Based)** |
| ⭑ Sibling EDP(s) | Single Page Web App Hosting on AWS *(same parent Solution Pattern, different CSP)* |
| Solution Architect | @*(to assign — I&O Solution Architecture)* |
| Reviewer(s) | @*(I&O Engineering)* · ⭑ @*(BISO — Consulted, security implications present, per v1.4 RACI update)* |
| Approver(s) | ⭑ Design Authority *(Accountable governing body for EDPs per v1.4)* |
| Approved Date | — |

---

## ⭑ Problem Statement & Intent

*(New section — v1.4 approval criteria require every pattern to articulate problem and intent. The current template opens with a service description; this opens with the engineering problem.)*

**Problem.** Azure is an enterprise-approved CSP with standing demand for browser-rendered applications backed by APIs, yet no approved engineering design exists for hosting them — a concrete instance of the Azure coverage gap in the EDP catalog. Teams building an SPA on Azure independently re-decide hosting, edge security, API mediation, token handling, and CORS posture. Each build carries its own security-review cycle, the decisions vary in quality, and none of the resulting implementations can be traced to approved architectural intent.

**Intent.** Define the single approved way to host a Single Page Web App on Azure, such that a compliant deployment is the default outcome of using the reference implementation, review effort concentrates on business-specific risk, and every implementation traces through this pattern to council-approved architecture.

## Description

The application shell is delivered through **Azure Static Web Apps** behind **Azure Front Door Premium** (WAF, TLS, security headers — the only public surface for content). All dynamic traffic flows as authenticated API calls through **Azure API Management**. Users authenticate **natively against Microsoft Entra ID** with Authorization Code + PKCE via MSAL.js — no brokering component, since Entra ID is the enterprise identity provider. This pattern realizes the **Single Page Web App Solution Pattern** on Azure; its sibling realizes the same parent on AWS.

## How it works

1. **Shell delivery.** Browser retrieves the shell (HTML/JS/CSS) via Front Door Premium → Static Web Apps (Standard). The origin is locked to Front Door (Private Link / header validation) and never directly reachable. TLS 1.2+ with managed certificates; WAF policy with managed ruleset in Prevention mode and bot protection; security headers via rules engine (HSTS ≥ 1 year, CSP without unsafe-inline scripts, X-Content-Type-Options, frame-ancestors 'none').
2. **Authentication.** MSAL.js (`@azure/msal-browser` 3.x) performs Authorization Code + PKCE directly against Entra ID; implicit flow disabled on the app registration (SPA platform profile); delegated scopes least-privilege; access tokens ≤ 60 minutes, held in memory/session per MSAL guidance — never localStorage. Enterprise MFA, Conditional Access, and joiner-mover-leaver governance apply automatically.
3. **API traffic.** All dynamic data flows through APIM (StandardV2, VNet-integrated): `validate-jwt` inbound policy (Entra issuer/audience), explicit CORS allow-list (no wildcards), throttling, private routing to backends. Backends are never reachable from the browser.
4. **Observability.** Diagnostic settings on Front Door, SWA, APIM, plus Entra sign-in logs → enterprise Log Analytics workspace (Canada Central); the reference implementation deploys the standard alarm pack and an availability test.
5. **Regions.** Canada Central (primary), Canada East (secondary) only — enterprise data residency.

## Diagram

*Diagram to be produced per catalog conventions. It shows:* end user (browser, untrusted zone) → Front Door Premium [TLS · WAF · headers] → Static Web Apps origin (locked) — shell path; browser ↔ Entra ID [Auth Code + PKCE, MSAL.js] — identity path; browser → APIM [validate-jwt · CORS allow-list] → backend services (private VNet) — data path; diagnostics from all components → enterprise Log Analytics. Trust boundary at Front Door and APIM.

## Use Cases

1. **Internal workforce applications** — browser-delivered business tools, workforce tenant authentication
2. **Customer-facing web applications** — external users via Entra External ID (variation V3)
3. **Application modernization** — replacing server-rendered legacy UIs with client-rendered applications over governed APIs
4. **Rich UI over existing enterprise APIs** — new experiences composed on already-approved API products

## Goals & Benefits

1. **Compliant by default** — WAF, TLS, PKCE, private origins, residency, and logging are outcomes of the reference implementation, not per-project decisions
2. **Reduced review effort** — security-relevant decisions are pre-made here once; project reviews focus on business-specific risk *(the framework's reference-implementation objective)*
3. **Simplest identity path on Azure** — native Entra ID integration adds zero identity components; enterprise identity governance applies by construction
4. **Closes the Azure coverage gap** — Azure-bound SPA workloads get a governed landing place with full lineage, matching the AWS sibling
5. **Independent scaling** — shell delivery scales at the edge irrespective of API load

## ⭑ Trade-offs & Constraints

*(Upgrades the current template's "Limitations" section. v1.4 requires design trade-offs; service quotas and limits belong in the Service Offering pages and are referenced, not restated.)*

1. **Static Web Apps managed-pipeline bounds** — build and CDN customization are constrained by the managed service; workloads needing low-level CDN control use variation V2 (Blob static hosting + Front Door)
2. **Front Door as critical path** — sole-ingress design concentrates availability and configuration risk at the edge; its WAF and rules configuration must be governed as the security perimeter it is
3. **Browser as untrusted runtime** — CSP discipline, dependency hygiene, and token handling are permanent obligations; nothing requiring a client secret can live in the SPA (by design — such logic belongs behind APIM)
4. **No server-side rendering** — SEO-critical or first-paint-critical applications need a server-rendered pattern (out of scope)
5. **Sibling divergence management** — delegated decisions may legitimately differ from the AWS sibling (identity path being the example), but inherited constraints must remain identical across siblings; drift on inherited items is a lineage defect and a review trigger
6. *Service-level quotas and limits:* per the referenced Service Offering pages

## ⭑ Inherited vs Delegated Decisions

*(New section — makes the framework's inheritance model explicit: what this EDP must honor versus what it decided.)*

**Inherited (constrained by lineage — deviation requires a governed exception via the Design Authority):**

| # | Constraint | Source |
|---|---|---|
| 1 | Shell via edge-secured static hosting; origin never public | Static Content Hosting (L2) via parent L3 |
| 2 | All API traffic through the governed gateway; no browser-to-backend paths | Gateway (L2) via parent L3 |
| 3 | Authentication against the enterprise IdP; standards-based public-client flow; no local credentials, no client secrets | Federated Identity (L2) via parent L3 |
| 4 | Browser untrusted; no data/secrets in shell; tokens never in persistent storage | Parent L3 trust model |
| 5 | Canadian data residency | Enterprise standard |

**Delegated (decided at this level — changing them changes this EDP only, never the lineage):**

| # | Decision | Rationale |
|---|---|---|
| 1 | Static Web Apps over Blob+Front Door and over App Service | Managed TLS/build/staging with native Front Door integration; Blob+Front Door retained as V2; App Service rejected (compute in the content path contradicts constraint 1's intent). *Record as ADR — aligns with the DAAP hosting evaluation (e.g., Coveo Atomic UI); validate and cite as real-world grounding* |
| 2 | Entra ID native, no broker | Entra ID *is* the enterprise IdP; deliberate divergence from the AWS sibling's Cognito-brokered approach — both satisfy inherited constraint 3 |
| 3 | APIM StandardV2, VNet-integrated | Private backend connectivity per enterprise network standards |
| 4 | Terraform via enterprise GitLab tflib | Consistency with existing reference implementation practice |

## ⭑ Variation Points

*(New section — declared flexibility prevents both rigidity and silent drift.)*

| # | Variation | Options | Default |
|---|---|---|---|
| V1 | UI framework | React 18+ / Angular 17+ / plain HTML+JS | React — *build step differs; hosting, security, and operations are identical, so the pattern is named by its design, not a framework* |
| V2 | Shell hosting | Static Web Apps / Blob static hosting + Front Door | Static Web Apps |
| V3 | Audience | Workforce tenant / Entra External ID | Workforce |

## Components/Services

Azure Static Web Apps (shell hosting) · Azure Front Door Premium (edge delivery + WAF) · Azure API Management (API mediation) · Microsoft Entra ID (identity) · Azure DNS · Azure Key Vault (pipeline/APIM secrets only — the SPA holds none) · Azure Monitor / Log Analytics / Application Insights (telemetry)

*Service mechanics, quotas, and pricing live in the linked Service Offering pages — deliberately not restated. This document records the design: how and why these services are composed.*

## When To Use

**Use this pattern when:** the application is browser-rendered; users authenticate against Entra ID (workforce or external); dynamic data flows through APIs called from the browser; Azure is the selected CSP.

**⭑ Do not use when:** content is identical for all users with no authenticated APIs → Static Content Web Site pattern; server-side rendering is required → server-rendered pattern *(to author)*; native mobile client → mobile pattern family; AWS is the selected CSP → sibling EDP.

**⭑ Boundary test:** does the browser authenticate users or call APIs? Yes → this pattern (on Azure). No → static pattern.

**⭑ Scope:** enterprise-wide, all business units deploying browser-rendered applications on Azure. Reuse is intentional: this pattern exists for repeated application, not a single project.

## ⭑ Pattern Lineage

*(Populates the current template's empty "Related Patterns" section with the framework's traceability requirement — the single most important addition.)*

| Relationship | Pattern | Level |
|---|---|---|
| Realizes | Single Page Web App | Solution Pattern |
| Inherits via parent | Static Content Hosting · Gateway · Federated Identity | Architecture Patterns |
| Inherits via parent | N-Tier (Web-Based) | Architecture Style |
| Sibling (same parent, different CSP) | Single Page Web App Hosting on AWS | EDP |
| Adjacent (boundary) | Static Content Web Site and its CSP EDPs *(candidates)* | Solution Pattern / EDP |

## Security

**Shared responsibility:** Microsoft secures the underlying services (security *of* the cloud); this pattern defines Canada Life's configuration responsibility (security *in* the cloud).

**Pattern posture:** only public surfaces are Front Door (shell) and APIM (APIs), both WAF-protected, TLS 1.2+; origins and backends private; no local credential store — enterprise MFA and Conditional Access apply natively; Authorization Code + PKCE only; tokens short-lived and in-memory; CSP forbids unsafe-inline scripts; explicit CORS allow-list; all diagnostics to enterprise logging; WAF in Prevention mode.

**Canada Life security controls:** DLP standard · InfraSec standard · AppSecOp standard · Data Retention and Disposal standard *(per MetricStream; links in Appendix)*. ⭑ **BISO is a Consulted reviewer of this pattern** per the Framework v1.4 RACI update.

## Cost Model

Chargeback (if any) to the business unit deploying this pattern. Cost drivers: Front Door data transfer + WAF, APIM capacity, Static Web Apps Standard, Log Analytics ingestion — unit costs per the linked Service Offering pages.

## ⭑ Reference Implementation

*(Upgrades "Deployment Strategy" from optional links to a mandatory element — per the framework's reference-implementation objective, an EDP without a reusable implementation asset is guidance, not a pattern.)*

- **Terraform module:** `gitlab.com/canada-life/TEP/cloud-platform-engineering/cloud/azure/library/platform-azure-tflib-spa-hosting` *(placeholder — create mirroring the existing AWS tflib structure; provisions Front Door endpoint + WAF policy, SWA with origin lockdown, APIM linkage, diagnostic settings, alarm pack, availability test)*
- **Pipeline template:** enterprise CI/CD — build per V1, SAST/SCA gates, deploy, availability-test registration
- **Provisioning rule:** production resources exclusively via the module; portal-created production resources are a **deviation** requiring a governed **exception** *(v1.4 §9 terminology)*

## Review History

| Version # | Changes | Solution Architect | Review Date | Reviewer(s) | Approved Date | Approver(s) | Notes |
|---|---|---|---|---|---|---|---|
| 0.1 | Initial draft on the proposed enhanced EDP structure | *(to assign)* | | | | | ⭑ additions per Pattern Framework v1.4 |

## Appendix

**References:** Canada Life Pattern Framework v1.4 · Parent Solution Pattern: Single Page Web App (incl. §6.1 dual-CSP technology mapping) · Sibling: SPA Hosting on AWS · CL applicable standards via MetricStream · Microsoft documentation (Static Web Apps, Front Door Premium, APIM validate-jwt, MSAL.js, Entra External ID) · ADR to record: shell hosting selection (SWA vs Blob+Front Door vs App Service)

**Validation checklist before socialization:** assign EDP-<N> (Bassem's catalog) · confirm TBM values · validate the DAAP Coveo Atomic hosting evaluation as cited real-world grounding · confirm identity configuration details with Identity Engineering and BISO · confirm offering page links

**⭑ Summary of proposed template additions (the I&O ask):** Problem Statement & Intent · Trade-offs & Constraints (replacing service-quota Limitations) · Inherited vs Delegated Decisions · Variation Points · Pattern Lineage (populating Related Patterns) · strengthened When To Use with boundary test and Scope · lifecycle-aligned Status values · Design Authority as approver and BISO as consulted reviewer · Reference Implementation as mandatory. Everything else is the existing template, unchanged.
