EVENT-DRIVEN PATTERNS — PATTERN FRAMEWORK DEMONSTRATION PACKAGE (LINEAGE 2)
Canada Life Pattern Framework v1.4 · Anchored on existing catalog EDP-15

CONTENTS (read 00-Package-Overview.docx first)
  00  Package Overview (start here — links to everything)
  01  L1 Architecture Style — Event-Driven Architecture
  02  L2 Architecture Pattern — Publisher-Subscriber
  03  L2 Architecture Pattern — Queue-Based Load Leveling
  04  L3 Solution Pattern — SaaS-to-SIEM Event Ingestion (new — bridges
      the lineage gap above EDP-15)
  05  L4 EDP-15 — SaaS-to-SIEM on AWS (EXISTING catalog EDP, identity
      preserved, re-expressed on the enhanced structure; items marked
      with a double-dagger must be reconciled against the current
      EDP-15 Confluence page before review)

Companion to the Web Application Patterns package (Lineage 1).

IMPORTANT — CROSS-DOCUMENT LINKS
Extract ALL files into ONE folder and keep them together. Hyperlinks
between documents are relative and resolve only when the files sit
side by side. Do not rename the files. Word may show a security prompt
on first click of a cross-document link; choose Yes/Allow.
