WEB APPLICATION PATTERNS — PATTERN FRAMEWORK DEMONSTRATION PACKAGE
Canada Life Pattern Framework v1.4 · All patterns in Proposed state

CONTENTS (read 00-Package-Overview.docx first)
  00  Package Overview (start here — links to everything)
  01  L1 Architecture Style — N-Tier (Web-Based)
  02  L2 Architecture Pattern — Static Content Hosting  (two consumers: 05 and 09)
  03  L2 Architecture Pattern — Gateway
  04  L2 Architecture Pattern — Federated Identity
  05  L3 Solution Pattern — Single Page Web App
  06  L4 EDP — Single Page Web App Hosting on AWS
  07  L4 EDP — Single Page Web App Hosting on Azure
  08  EDP Base Template — Enhanced (reusable for all future EDPs)
  09  L3 Solution Pattern — Static Content Web Site (single-tier demonstrator)
  10  L4 EDP — Static Website Hosting on AWS
  11  L4 EDP — Static Website Hosting on Azure

IMPORTANT — CROSS-DOCUMENT LINKS
Extract ALL files into ONE folder and keep them together. The hyperlinks
between documents (e.g., clicking a parent pattern in an EDP's lineage)
are relative and resolve only when the files sit side by side. Do not
rename the files, or the links will break. Word may show a security
prompt on first click of a cross-document link; choose Yes/Allow.
